# -*- coding: utf-8 -*-
import scrapy
from babyEtsy.items import BabyetsyItem
import time


class mySpider(scrapy.Spider):
    name = "etsySpider"
    allowed_urls = ["https://www.etsy.com"]
    start_urls = ['https://www.etsy.com/c/accessories/baby-accessories/baby-carriers-and-wraps?explicit=1&locationQuery=6252001']


    def parse(self, response):
    	start_urls = ['https://www.etsy.com/c/accessories/baby-accessories/baby-carriers-and-wraps?explicit=1&locationQuery=6252001']
        last_page_number = 2
        print "=" * 50
        print "start spider"
        page_urls = [start_urls[0] + "&page=" + str(pageNumber) for pageNumber in range(1, last_page_number + 1)]
        for page_url in page_urls:
            yield scrapy.Request(page_url, 
                                    callback=self.parse_listing_results_page)

    def parse_listing_results_page(self, response):
    	print "parse result page"
    	time.sleep(2)
    	ids = response.xpath('//div[@class="block-grid-item listing-card position-relative parent-hover-show"]/@data-palette-listing-id').extract()
    	print len(ids)
        	
        for id in ids:
        	url = "https://www.etsy.com/listing/" + id
        	yield scrapy.Request(url, callback=self.parse_listing_contents)


    def parse_listing_contents(self, response):
        item = BabyetsyItem()
        # product = response.xpath('//span[@itemprop ="name"]').extract()

        item['price'] = response.xpath('//span[@id="listing-price"]/meta[@itemprop="price"]/@content').extract()
        print item['price']
        
        # shopName = response.xpath('//span[@itemprop="title"]').extract()
        # shopLocation = response.xpath('//div[@id="shop-info"]/text()').extract()
        # itemCount = response.xpath('//span[@class="count-number"]').extract()
        # feedback = response.xpath('//a[@href="#reviews"]').extract()
        # favorited = response.xpath('//*[@id="item-overview"]/ul/li[6]/a').extract()
        # relitemTag = response.xpath('//div[@id="tags"]/ul[@id="listing-tag-list"]/a[@href="https://www.etsy.com/c/accessories?ref=l2"]').extract()
        # listDate = response.xpath('//*[@id="fineprint"]/ul/li[1]').extract()
        # views = response.xpath('//*[@id="fineprint"]/ul/li[2]').extract()
        # color = response.xpath('//*[@id="variations"]/div/div[2]/select[@class="variation"]').extract()


    	print "We get to the detail page"

        
