

#use df_shiny90
data <- df_shiny95_r
data$Region <- as.factor(data$Region)

##or data=read.csv(shiny_long95.csv)
##
