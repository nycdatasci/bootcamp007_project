library(dplyr)

shinyServer(function(input, output, session) {
  
  defaultColors <-
    c("#3366cc",
      "#dc3912",
      "#ff9900",
      "#109618",
      "#990099",
      "#0099c6",
      "#dd4477")
  series <- structure(lapply(defaultColors, function(color) {
    list(color = color)
  }),
  names = levels(data$Region))
  
  yearData <- reactive({
    df <- data %>%
      filter(Year == input$year) %>%
      select(CountryName,
             Sanitation.Facilities,
             Life.Expectancy,
             Region,
             Population) %>%
      arrange(Region)
  })
  
  output$chart <- reactive({
    # Return the data and options
    list(data = googleDataTable(yearData()),
         options = list(
           title = sprintf("Sanitation.Facilities vs. Life Expectancy, %s",
                           input$year),
           series = series
         ))
  })
})