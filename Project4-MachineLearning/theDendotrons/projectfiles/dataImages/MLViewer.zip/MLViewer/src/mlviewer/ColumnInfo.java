package mlviewer;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author nathan
 */
public class ColumnInfo {
    private String name;
    private ArrayList<String> keyList = new ArrayList<String>();
    private ArrayList<String> valueList = new ArrayList<String>();
    private int length = 0;
    
    /**
     * Store the column info
     * @param name
     * @param keys
     * @param values 
     */
    public ColumnInfo(String name, String[] keys, String[] values) {
        this.name = name;
        this.length = keys.length;
        
        for(int i  = 0; i < keys.length; i++) {
            keyList.add(keys[i]);
            valueList.add(values[i]);
        }
    }
    
    /**
     * get the color value
     */
    public int[] getColorValue(String key) {
        int[] colorValue = new int[3];
        
        if(name.indexOf("cat") != -1) {
            int index = keyList.indexOf(key) + 1;
            float f = index/(float)length;
            int gray = (int)(f*255);
            colorValue[0] = colorValue[1] = colorValue[2] = gray;
        } else {
            double value = Double.parseDouble(key);
            double max = Double.parseDouble(valueList.get(5));
            
            if(name.indexOf("loss") == -1) {
                int gray = (int)((value/max)*255);
                colorValue[0] = colorValue[1] = colorValue[2] = gray;
            } else {
                if(value < (Math.log(3800) + 1)) {
                    int green = (int)((value/(Math.log(3800) + 1))*255);
                    
                    colorValue[0] = 0;
                    colorValue[1] = checkColor(green);
                    colorValue[2] = 0;
                } else {
                    int red = (int)((value/(Math.log(121000) + 1))*255);
                    
                    colorValue[0] = checkColor(red); 
                    colorValue[1] = 0;  
                    colorValue[2] = 0;
                }
            }
        }
        
        return colorValue;
    }
    
    /**
     * Check to make sure color value is between 0 and 255
     * @param color
     * @return 
     */
    private int checkColor(int color) {
        if(color < 0) {
            return 0;
        } else if (color > 255) {
            return 255;
        } else {
            return color;
        }
    }
    
    @Override
    public String toString() {
        return name;
    }
}
